---
name: chatgpt-image
description: Generate or edit raster images through the paid OpAgent ChatGPT Image service. Use this skill when the user asks to create, transform, or revise bitmap images and the installed package provides bin/opagent-image.
---

# ChatGPT Image

Use the bundled CLI instead of calling OpenAI directly:

```bash
bin/opagent-image generate --prompt "<prompt>" --cwd "<workspace>"
bin/opagent-image edit --image "<path>" --prompt "<prompt>" --cwd "<workspace>"
```

The CLI reads OpAgent auth from `~/.opagent/configs/user/auth.json` or `$OPAGENT_BASE_DIR/configs/user/auth.json`, calls the paid AI gateway image endpoints, saves generated files under `<workspace>/.agent/assets/images`, and prints JSON.

## Workflow

1. Use `generate` for new images and `edit` when there is an existing source image.
2. Pass the active workspace as `--cwd`; do not write image outputs outside the workspace unless the user explicitly asks.
3. Use `--size`, `--quality`, `--format`, `--background`, and `--n` only when the user requests them or the task clearly needs them.
4. Read the JSON result and use its `images[].markdown` or `images[].path` in the final answer.

## Commands

Generate:

```bash
bin/opagent-image generate \
  --prompt "A clean product mockup on a white background" \
  --cwd "$PWD" \
  --size 1024x1024 \
  --quality auto \
  --format png
```

Edit:

```bash
bin/opagent-image edit \
  --image input.png \
  --prompt "Keep the object shape, change the background to transparent" \
  --cwd "$PWD" \
  --format png
```

If the prompt is long, write it to a temporary text file and pass `--prompt-file`.
